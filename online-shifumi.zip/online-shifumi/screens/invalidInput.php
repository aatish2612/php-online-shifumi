<?php

function getInvalidUserInputMessage(): string{
    return "Choix invalide. Tapez sur entrée pour revenir à l'écran précédent...";
}
